package com.cts.freelancer.bean;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="ProposedProject")
public class ProposedProject { 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int proposedProjectId=1;
	private int adminId;
	@OneToMany(targetEntity=Project.class)
	private List<Project> projectList=new ArrayList<Project>();
	@OneToOne(targetEntity=User.class)
	private User user;
	private long budget;
	private LocalDate proposalDate;
	private String proposalStatus;
	
	
	public int getProposedProjectId() {
		return proposedProjectId;
	}
	public void setProposedProjectId(int proposedProjectId) {
		this.proposedProjectId = proposedProjectId;
	}
	
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	
	
	
	
	public List<Project> getProjectList() {
		return projectList;
	}
	public void setProjectList(List<Project> projectList) {
		this.projectList = projectList;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public long getBudget() {
		return budget;
	}
	public void setBudget(long budget) {
		this.budget = budget;
	}
	public LocalDate getProposalDate() {
		return proposalDate;
	}
	public void setProposalDate( LocalDate  proposalDate) {
		this.proposalDate = proposalDate;
	}
	public String getProposalStatus() {
		return proposalStatus;
	}
	public void setProposalStatus(String proposalStatus) {
		this.proposalStatus = proposalStatus;
	}
	@Override
	public String toString() {
		return "ProposedProject [proposedProjectId=" + proposedProjectId + ", adminId=" + adminId + ", projectList="
				+ projectList + ", user=" + user + ", budget=" + budget + ", proposalDate=" + proposalDate
				+ ", proposalStatus=" + proposalStatus + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + adminId;
		result = prime * result + (int) (budget ^ (budget >>> 32));
		result = prime * result + ((projectList == null) ? 0 : projectList.hashCode());
		result = prime * result + ((proposalDate == null) ? 0 : proposalDate.hashCode());
		result = prime * result + ((proposalStatus == null) ? 0 : proposalStatus.hashCode());
		result = prime * result + proposedProjectId;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProposedProject other = (ProposedProject) obj;
		if (adminId != other.adminId)
			return false;
		if (budget != other.budget)
			return false;
		if (projectList == null) {
			if (other.projectList != null)
				return false;
		} else if (!projectList.equals(other.projectList))
			return false;
		if (proposalDate == null) {
			if (other.proposalDate != null)
				return false;
		} else if (!proposalDate.equals(other.proposalDate))
			return false;
		if (proposalStatus == null) {
			if (other.proposalStatus != null)
				return false;
		} else if (!proposalStatus.equals(other.proposalStatus))
			return false;
		if (proposedProjectId != other.proposedProjectId)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
	
	
}
