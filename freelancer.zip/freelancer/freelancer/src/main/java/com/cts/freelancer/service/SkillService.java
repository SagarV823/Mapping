package com.cts.freelancer.service;

import java.util.List;


import com.cts.freelancer.bean.Skills;


public interface SkillService {
	public List<Skills> fetchSkills(List<String> fetch);
}
