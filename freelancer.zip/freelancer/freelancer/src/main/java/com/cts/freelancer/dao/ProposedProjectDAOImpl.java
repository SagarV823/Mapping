package com.cts.freelancer.dao;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.ProposedProject;

@Repository
public class ProposedProjectDAOImpl implements ProposedProjectDAO{
	
	@Autowired
	SessionFactory sessionFactory;
	@Transactional
	public boolean saveProposedProject(ProposedProject proposedProject){
		Session session =sessionFactory.getCurrentSession();
		session.save(proposedProject);
		return true;
	}
	@Transactional
	public int fetchAdminIdByProjectId(int projectId) {
		
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("select p.adminId from Project p where projectId=?");
		query.setParameter(0, projectId);
		int project=(int)query.getSingleResult();
		return project;
	}
	
	
	
}
