package com.cts.freelancer.dao;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.ProposedProject;

public interface ProposedProjectDAO {
	public boolean saveProposedProject(ProposedProject proposedProject);
	public int fetchAdminIdByProjectId(int projectId);
}
