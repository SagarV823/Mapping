package com.cts.freelancer.dao;

import java.util.List;

import com.cts.freelancer.bean.Skills;

public interface SkillDAO {
	public List<Skills> fetchSkills(List<String> fetch);
}
