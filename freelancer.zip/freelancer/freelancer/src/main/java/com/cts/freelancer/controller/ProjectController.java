package com.cts.freelancer.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.ProposedProject;
import com.cts.freelancer.bean.Skills;
import com.cts.freelancer.service.AdminLoginService;
import com.cts.freelancer.service.ProjectService;
import com.cts.freelancer.service.SkillService;
@Controller
public class ProjectController {
	 @Autowired
	    ProjectService projectService;
	 @Autowired
	 	SkillService skillService;
	 @Autowired
	 	AdminLoginService adminService;
	 
	 
	 
	 
	 	@RequestMapping(value="registerProject",method=RequestMethod.POST)	
	 	public ModelAndView registerProject(@RequestParam("projectName") String projectName,@RequestParam("projectDuration") String projectDuration,@RequestParam("projectBudget") long projectBudget,@RequestParam("skills") List<String> skills,@RequestParam("remarks") String remarks,HttpServletRequest request ){
			Project project=new Project();
			project.setProjectName(projectName);
			project.setProjectDuration(projectDuration);
			List<Skills> skillset=skillService.fetchSkills(skills);
			project.setSkills(skillset);
			project.setRemarks(remarks);
			String emailId=(String)request.getSession().getAttribute("emailId");
			
			request.getSession().setAttribute("budget",projectBudget);
			
			int adminId=adminService.fetchAdminId(emailId);
			project.setAdminId(adminId);	
	 		ModelAndView mv=new ModelAndView();
			boolean result=projectService.registerProject(project);
			if(result){
	    		mv.addObject("name","Project"+project.getProjectName()+" added!");
	    		mv.setViewName("adminWelcome");
			}
			else
				mv.setViewName("error");	
			skillset.clear();
			return mv;		
		}
}

