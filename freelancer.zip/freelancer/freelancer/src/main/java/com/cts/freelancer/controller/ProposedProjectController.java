package com.cts.freelancer.controller;

import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.ProposedProject;
import com.cts.freelancer.bean.User;
import com.cts.freelancer.service.ProjectService;
import com.cts.freelancer.service.ProposedProjectService;

@Controller
public class ProposedProjectController {

	@Autowired
	ProjectService projectService;
	@Autowired
	ProposedProjectService proposedProjectService;
	
	@RequestMapping(value="requestProject")
	public ModelAndView saveProposedProject(@RequestParam("id") int projectId,HttpServletRequest request) 
	{	
		int adminIdByProjectId=proposedProjectService.fetchAdminIdByProjectId(projectId);
		System.out.println("projectId  "+projectId);
		System.out.println("adminIdByProjectId "+adminIdByProjectId);
		ProposedProject proposedProject=new ProposedProject();
		proposedProject.setAdminId(adminIdByProjectId);
		long projectBudget=(long)request.getSession().getAttribute("budget");
		User user=(User)request.getSession().getAttribute("userobject"); 
		proposedProject.setUser(user);
		
		proposedProject.setBudget(projectBudget);
		proposedProject.setProposalDate(LocalDate.now());
		String status="Waiting for Admin Response";
		proposedProject.setProposalStatus(status);
		
		List<Project> projectList=(List<Project>)request.getSession().getAttribute("userProject");
		
		proposedProject.setProjectList(projectList);
		
		//saveProjectInfoInProposedProject.
		
		
		ModelAndView mv=new ModelAndView();
		boolean result=proposedProjectService.saveProposedProject(proposedProject);
		if(result){
    		System.out.println("Proposed Project Table updated successully.");
		}
		else
			mv.setViewName("error");
		return mv;	
		
		
	}
	
	
	
	
}
