package com.cts.freelancer.service;

import java.util.List;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.User;

public interface FetchService {

	
	
	public Admin getAdminObject(int adminId);
	public User getUserObject(int userId);
//	public List<Project> getProjectObject(int adminId);
	public List<Project> getProjectObject();
	public List<Project> minimumSkillMatch(int userId,List<Project> projectList);
	
}
