package com.cts.freelancer.dao;

import com.cts.freelancer.bean.Project;

public interface ProjectDAO {

	public boolean registerProject(Project project);
	
}