package com.cts.freelancer.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;
import org.springframework.transaction.annotation.Transactional; 

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.Skills;
import com.cts.freelancer.bean.User;
import com.cts.freelancer.service.AdminLoginService;
import com.cts.freelancer.service.ProjectService;

@Repository
public class FetchObejectsDAOImpl implements FetchObejectsDAO{
	
	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	AdminLoginService adminService;
	@Autowired
	ProjectService  projectService;
	@Transactional
	public Admin getAdminObject(int adminId)
	{
		Session session=sessionFactory.getCurrentSession();
		Query fetchAdminObject=session.createQuery("from Admin where adminId=?");
		fetchAdminObject.setParameter(0,adminId);
		Admin adminObject=(Admin)fetchAdminObject.getSingleResult();
		return adminObject;
	}
	@Transactional
	public List<Project> minimumSkillMatch(int userId,List<Project> projectList){
		Session session=sessionFactory.getCurrentSession();
		Query userskill=session.createQuery("select u.skills from User u where u.userId=:userId");
		userskill.setParameter("userId",userId);
		 System.out.println("Current User:   "+userId);
		List<Skills> userskilllist=(List<Skills>)userskill.getResultList();
		for(int i=0;i<userskilllist.size();i++){
		    System.out.println(userskilllist.get(i));
		}
		System.out.println("********************************************************************");
		List<Project> minimummskillmatch=new ArrayList<Project>();
		Iterator iterator=projectList.iterator();
		 while (iterator.hasNext()) 
		 {
			Project project=(Project)iterator.next();
	
			boolean test=userskilllist.containsAll(project.getSkills());
			System.out.println(project.getSkills());
			System.out.println("Test Boolean value: "+test);
			
			if(test)
			{System.out.println("In If condition");
				minimummskillmatch.add(project);
			
			}
		 }	
		 for(int i=0;i<minimummskillmatch.size();i++){
			    System.out.println(minimummskillmatch.get(i));
			}
		return minimummskillmatch;		
	}
	
	/*public List<Project> getProjectObject(int adminId)
	{
		Session session=sessionFactory.getCurrentSession();
		Query fetchProjectObject=session.createQuery("from Project where adminId=?");
		fetchProjectObject.setParameter(0,adminId);
		List<Project> projectObject=(List<Project>)fetchProjectObject.getResultList();
		return projectObject;
	}*/
	@Transactional
	public List<Project> getProjectObject()
	{
		Session session=sessionFactory.getCurrentSession();
		Query fetchProjectObject=session.createQuery("from Project");
		List<Project> projectObject=(List<Project>)fetchProjectObject.getResultList();
		return projectObject;
	}
	
	@Transactional
	public User getUserObject(int userId) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		Query fetchUserObject=session.createQuery("from User where userId=?");
		fetchUserObject.setParameter(0, userId);
		User userobject=(User)fetchUserObject.getSingleResult();
		return userobject;
	}	
}
