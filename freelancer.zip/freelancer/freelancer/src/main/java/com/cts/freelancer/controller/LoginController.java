package com.cts.freelancer.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.ProposedProject;
import com.cts.freelancer.bean.Skills;
import com.cts.freelancer.bean.User;
import com.cts.freelancer.service.AdminLoginService;
import com.cts.freelancer.service.FetchService;
import com.cts.freelancer.service.SkillService;
import com.cts.freelancer.service.UserLoginService;

@Controller
public class LoginController {
	
	@Autowired
	AdminLoginService adminLoginService;
	@Autowired
	UserLoginService userLoginService;
	@Autowired
	SkillService skillService;
	@Autowired 
	FetchService fetchService;
	
	  @RequestMapping("adminLoginPage")
	  public String loginAdminScreen()
	  {
		  return "adminLogin";
	  }
	

    @RequestMapping(value="registerAdmin",method=RequestMethod.POST)
    public ModelAndView registerAdmin(@ModelAttribute Admin admin)
    {
    	ModelAndView modelAndView=new ModelAndView();
    	boolean result=adminLoginService.registerAdmin(admin);
    	if(result)
    	{
    		modelAndView.setViewName("adminLogin");
    		modelAndView.addObject("admin",admin);
    		
    	}
    	else
    	modelAndView.setViewName("error");
    	return modelAndView;
    }
    

	 
	  @RequestMapping(value="adminLoginAuth",method=RequestMethod.POST)
	    public ModelAndView adminAuthentication(@RequestParam("emailId") String emailId,@RequestParam("password") String password,HttpServletRequest request)
	    {
		  	request.getSession().setAttribute("emailId", emailId);
	    	ModelAndView modelAndView=new ModelAndView();
	    	boolean result=adminLoginService.authenticate(emailId, password);
	    	if(result)
	    	{
	    		int adminId=adminLoginService.fetchAdminId(emailId);
	    		Admin adminObject=fetchService.getAdminObject(adminId);
	    		request.getSession().setAttribute("adminobject",adminObject);
	    		modelAndView.setViewName("adminWelcome");
	    		modelAndView.addObject("user",emailId);
	    		
	    	}
	    	else
	    		modelAndView.setViewName("error");
	    	return modelAndView;
	    }

	  	
	  @RequestMapping(value="registerUser",method=RequestMethod.POST)
		public ModelAndView registerUser(@RequestParam("firstName") String firstName,@RequestParam("lastName") String lastName,@RequestParam("emailId") String emailId,@RequestParam("phoneNumber") String phoneNumber,@RequestParam("password") String password,@RequestParam("skill") List<String> skill )
		{
		  	User user=new User();
		  	user.setFirstName(firstName);
		  	user.setLastName(lastName);
		  	user.setEmailId(emailId);
		  	user.setPhoneNumber(phoneNumber);
		  	user.setPassword(password);
		  	List<Skills> skillSetUser=skillService.fetchSkills(skill);
		  	user.setSkills(skillSetUser);
			ModelAndView modelAndView=new ModelAndView();
			boolean result=userLoginService.registerUser(user);
			if(result)
			{
				modelAndView.setViewName("userLogin");
			}
			else
			{	
				modelAndView.setViewName("error");
			}
			return modelAndView;
		}


		  @RequestMapping(value="userLoginAuth",method=RequestMethod.POST)
		    public ModelAndView userAuthentication(@RequestParam("emailId") String emailId,@RequestParam("password") String password,HttpServletRequest request)
		    {	
		    	ModelAndView modelAndView=new ModelAndView();
		    	request.getSession().setAttribute("useremail",emailId);
		    	boolean result=userLoginService.authenticate(emailId, password);
		    	System.out.println(result);
		    	if(result)
		    	{
		    		int userId=userLoginService.fetchUserId(emailId);
		    		User userObject=fetchService.getUserObject(userId);
		    		request.getSession().setAttribute("userobject", userObject);
		    		List<Project> projectList=fetchService.getProjectObject();
		    		List<Project> projectOnBasisOfSkills=fetchService.minimumSkillMatch(userId, projectList);
		    		
		    		request.getSession().setAttribute("userProject",projectOnBasisOfSkills );
		    		modelAndView.setViewName("userWelcome");
		    		modelAndView.addObject("lancer",emailId);
		    	
		    	}
		    	else
		    	modelAndView.setViewName("error");
		    	return modelAndView;
		    }
		  	
		  @RequestMapping(value="userLoginPage")
		  public String loginUserScreen(){
			return "userLogin";  
		  }
			

}
