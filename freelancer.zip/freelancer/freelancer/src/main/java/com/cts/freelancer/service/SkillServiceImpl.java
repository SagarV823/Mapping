package com.cts.freelancer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.freelancer.bean.Skills;
import com.cts.freelancer.dao.SkillDAO;

@Service
public class SkillServiceImpl implements SkillService{
	@Autowired
	private SkillDAO skilldao;

	@Override
	public List<Skills> fetchSkills(List<String> fetch) {
		return skilldao.fetchSkills(fetch);
	}
	
}
