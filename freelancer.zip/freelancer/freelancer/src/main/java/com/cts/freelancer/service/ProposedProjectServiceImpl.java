package com.cts.freelancer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.ProposedProject;
import com.cts.freelancer.dao.ProposedProjectDAO;
@Service
public class ProposedProjectServiceImpl implements ProposedProjectService{

	@Autowired
	ProposedProjectDAO proposedProjectDAO;
	
	
	public boolean saveProposedProject(ProposedProject proposedProject) {
		// TODO Auto-generated method stub
		return proposedProjectDAO.saveProposedProject(proposedProject);
	}


	@Override
	public int fetchAdminIdByProjectId(int projectId) {
		// TODO Auto-generated method stub
		return proposedProjectDAO.fetchAdminIdByProjectId(projectId);
	}

}
