package com.cts.freelancer.dao;

import java.util.List;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.User;

public interface FetchObejectsDAO {
	public Admin getAdminObject(int adminId);
	public User getUserObject(int userId);
	public List<Project> minimumSkillMatch(int userId,List<Project> projectList);
	//public List<Project> getProjectObject(int adminId);
	public List<Project> getProjectObject();
}
