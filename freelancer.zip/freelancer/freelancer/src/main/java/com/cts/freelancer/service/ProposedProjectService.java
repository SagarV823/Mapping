package com.cts.freelancer.service;

import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.ProposedProject;

public interface ProposedProjectService {
	public boolean saveProposedProject(ProposedProject proposedProject);
	public int fetchAdminIdByProjectId(int projectId);
}
