package com.cts.freelancer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.bean.Project;
import com.cts.freelancer.bean.User;
import com.cts.freelancer.dao.FetchObejectsDAO;
@Service
public class FetchServiceImpl implements FetchService{

	@Autowired
	FetchObejectsDAO fetchobjects;
	@Override
	public Admin getAdminObject(int adminId) {
		// TODO Auto-generated method stub
		return fetchobjects.getAdminObject(adminId);
	}

	@Override
	public List<Project> minimumSkillMatch(int userId, List<Project> projectList) {
		// TODO Auto-generated method stub
		return fetchobjects.minimumSkillMatch(userId, projectList);
	}

	/*
	 public List<Project> getProjectObject(int adminId) {
		// TODO Auto-generated method stub
		return fetchobjects.getProjectObject(adminId);
	}
*/
	@Override
	public List<Project> getProjectObject() {
		// TODO Auto-generated method stub
		return fetchobjects.getProjectObject();
	}

	@Override
	public User getUserObject(int userId) {
		// TODO Auto-generated method stub
		return fetchobjects.getUserObject(userId);
	}

}
