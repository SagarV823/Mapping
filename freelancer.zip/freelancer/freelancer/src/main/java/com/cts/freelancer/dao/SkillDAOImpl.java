package com.cts.freelancer.dao;

import java.util.ArrayList;
import java.util.List;
import org.springframework.transaction.annotation.Transactional; 

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.freelancer.bean.Skills;
import com.cts.freelancer.dao.SkillDAO;
@Repository
public class SkillDAOImpl implements SkillDAO{
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;

	
	@Transactional
	public List<Skills> fetchSkills(List<String> fetch) {
		List<Skills> listskills=new ArrayList<Skills>();
		Session session=sessionFactory.getCurrentSession();
		for (int i = 0; i < fetch.size(); i++) {
		Query fetchskillquery=session.createQuery("from Skills where skillName=?");
		fetchskillquery.setParameter(0,fetch.get(i));
		Skills list=(Skills)fetchskillquery.uniqueResult();
		listskills.add(list);
		}
		return listskills;
	}

}
